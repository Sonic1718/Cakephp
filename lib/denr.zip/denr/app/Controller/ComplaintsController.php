<?php

App::uses('AppController', 'Controller');
App::uses('CakeEmail', 'Network/Email');

class ComplaintsController extends AppController {
	 
	

	public function display() {
		
	}


	public function complaint() {
		$this->layout = "complaint";

		if($this->request->is('post')){
			
			$this->Complaint->set($this->request->data);
			$this->Complaint->Picture->set($this->request->data);
			if($this->Complaint->validates() && $this->Complaint->Picture->validates() ){	
				//get the extenion file
				$ext = end((explode('.',$this->request->data['Picture']['image']['name'])));
				$newName = time().'.'.$ext;
		
				//upload directory
				$dir = WWW_ROOT.'/picture/'.$newName;
				$filename = $this->request->data['Picture']['image']['tmp_name'];
				
				  if(move_uploaded_file($filename, $dir)){
					if( $this->Complaint->save($this->request->data['Complaint']) && 
						$this->Complaint->Picture->save(array('complaint_id'=>$this->Complaint->id,'image' => $newName))){

							$this->Session->write('promp',"<script src='/js/jquery.js'></script>
						             <script type='text/javascript'>
                      				    $(window).load(function(){
                      				        $('#myModal').modal('show');
                      				    });
                      				 </script>
                      				 <div class='modal fade' id='myModal' role='dialog'>
                      				   <div class='modal-dialog'>
                      				   
                      				     <!-- Modal content-->
                      				     <div class='modal-content'>
                      				       <div class='modal-header bg-success'>
                      				         <button type='button' class='close' data-dismiss='modal'>&times;</button>
                      				         <h4 class='modal-title'>Attention Applicant</h4>
                      				       </div>
                      				       <div class='modal-body'>
                      				         <p>Your Complaint Successfully Submited</p>
                      				       </div>
                      				       <div class='modal-footer'>
                      				         <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
                      				       </div>
                      				     </div>
                      				     
                      				   </div>
                      				 </div>
                      				 ");
					

						 $this->redirect('complaint');


					} else {
						$this->Session->Setflash('Please try Again');
						$this->redirect($this->request->here);
					}
				  } else {
				  	$this->Session->Setflash('Please try Again');
				  	$this->redirect($this->request->here);
				  }
			}
		 $this->set('posts', $this->paginate());
	   }


	  $this->set('subjects',$this->Complaint->Subject->find('all'));
    }

    public function member_complaint() { 
		$this->layout = 'member';
		
		$this->paginate = array(
			'limit' => 5
		);

		if($this->request->is('ajax')){
			$this->layout = '';
		}

		$this->set('posts', $this->paginate('Complaint'));
	}

	public function member_viewcomplaint($id){

		$result = $this->Complaint->findById($id);
		$this->set('result',$result);
		
		$this->loadModel('User');
		$user = $this->User->findById($result['Complaint']['user_id']);
        //get-email
        //$user['User']['email'];

		
		

		if ( $this->request->is('post') ) {

			$Email = new CakeEmail('smtp');			

			$message = '<br><h3>' . $result['Subject']['subject'] . '</h3><br>'. $result['Complaint']['message'];

			$Email->template('denr')
			      ->viewVars($message)
			      ->emailFormat('both')
			      ->to($user['User']['email'])
			      ->subject('About')
			      ->send('My message');

				$this->Session->write('promp',
					"<script type='text/javascript'>
						    $(window).load(function(){
						        $('#myModal').modal('show');
						    });
						</script>
							 <div class='modal fade' id='myModal' role='dialog'>
							   <div class='modal-dialog'>
							   
							     <!-- Modal content-->
							     <div class='modal-content'>
							       <div class='modal-header bg-success'>
							         <button type='button' class='close' data-dismiss='modal'>&times;</button>
							         <h4 class='modal-title'>Attention Member Personnel</h4>
							       </div>
							       <div class='modal-body'>
							         <p>You Successfully Submited Notification to Complainant..</p>
							       </div>
							       <div class='modal-footer'>
							         <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
							       </div>
							     </div>
							     
							   </div>
							 </div>
					"
				);
			$this->redirect($this->here);
		}
	}

	public function member_deletecomplaint($id){

		$result = $this->Complaint->findById($id);
		
		if (unlink(WWW_ROOT.'picture/'.$result['Picture'][0]['image'])) {
			$this->Complaint->delete($id, true);
		    $this->redirect('/member/Complaints/complaint');
		}
	}


    public function admin_complaint() { 
		$this->layout = 'admin';
		
		$this->paginate = array(
			'limit' => 5
		);

		if($this->request->is('ajax')){
			$this->layout = '';
		}

		$this->set('posts', $this->paginate('Complaint'));
	}

	public function admin_viewcomplaint($id){

		$result = $this->Complaint->findById($id);
		$this->set('result',$result);

		$this->loadModel('User');
		$user = $this->User->findById($result['Complaint']['user_id']);
        //get-email
        //$user['User']['email'];

		if ( $this->request->is('post') ) {

			$Email = new CakeEmail('smtp');	
			
			$message = '<br><h3>' . $result['Subject']['subject'] . '</h3><br>'. $result['Complaint']['message'];

			$Email->template('denr')
			      ->viewVars($message)
			      ->emailFormat('both')
			      ->to($user['User']['email'])
			      ->subject('About')
			      ->send('My message');

				$this->Session->write('promp',
					"<script type='text/javascript'>
						    $(window).load(function(){
						        $('#myModal').modal('show');
						    });
						</script>
							 <div class='modal fade' id='myModal' role='dialog'>
							   <div class='modal-dialog'>
							   
							     <!-- Modal content-->
							     <div class='modal-content'>
							       <div class='modal-header bg-success'>
							         <button type='button' class='close' data-dismiss='modal'>&times;</button>
							         <h4 class='modal-title'>Attention Admin Personnel</h4>
							       </div>
							       <div class='modal-body'>
							         <p>You Successfully Submited Notification to Complainant..</p>
							       </div>
							       <div class='modal-footer'>
							         <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
							       </div>
							     </div>
							     
							   </div>
							 </div>
					"
				);
			$this->redirect($this->here);

		}
	}

	public function admin_deletecomplaint($id){

		$result = $this->Complaint->findById($id);
		
		if (unlink(WWW_ROOT.'picture/'.$result['Picture'][0]['image'])) {
			$this->Complaint->delete($id, true);
		    $this->redirect('/member/Complaints/complaint');
		}

	}



}
