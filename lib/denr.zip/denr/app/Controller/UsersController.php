<?php

App::uses('AppController', 'Controller');

class UsersController extends AppController {

	var $uses = array('User','Post','Landapproval','Forestapproval','Wildapproval');


	public function login(){
		//pr($this->request->data);
		$this->layout = 'loginregister';
		if($this->request->is('post')){
			if ($this->Auth->login()) {
		    	if($this->Auth->user('role') == 'admin') {
			        $this->redirect('/admin/posts');
		    	}else if($this->Auth->user('role') == 'member') {
			        $this->redirect('/member/posts');
		    	} else {
		    		 return $this->redirect('/');
		    	} 
			}else{
				$this->Session->setFlash('Invalid Username or Password!');
			}
		}
	}

	public function logout(){
		$this->Auth->logout();
		$this->redirect('/users/login');
	}

	public function admin_member(){
		if($this->request->is('post')){	
			pr($this->request->data);
			$this->User->create();
			if($this->User->save($this->request->data)){
				$this->Session->setFlash('New Member has been Added');
				return $this->redirect(array('action'=>'member'));
			}else{
				$this->Session->setFlash('Could not be registered');
			}
		}
	}
	
	public function register(){
		$this->layout = 'loginregister';

		if($this->request->is('post','put')){
			// $this->request->data['User']['password'] = AuthComponent::password($this->request->data['User']['password']);
			$this->User->create();
			if($this->User->save($this->request->data)){


                $land = array(
				   array('Landapproval' => array('user_id' => $this->User->id,'land'=>1 )),
				   array('Landapproval' => array('user_id' => $this->User->id,'land'=>2 )),
				   array('Landapproval' => array('user_id' => $this->User->id,'land'=>3 )),
				   array('Landapproval' => array('user_id' => $this->User->id,'land'=>4 )),
				   array('Landapproval' => array('user_id' => $this->User->id,'land'=>5 ))
				);
                $this->Landapproval->saveAll($land);
				
				$forest = array(
				   array('Forestapproval' => array('user_id' => $this->User->id,'forest'=>1 )),
				   array('Forestapproval' => array('user_id' => $this->User->id,'forest'=>2 )),
				   array('Forestapproval' => array('user_id' => $this->User->id,'forest'=>3 )),
				   array('Forestapproval' => array('user_id' => $this->User->id,'forest'=>4 )),
				   array('Forestapproval' => array('user_id' => $this->User->id,'forest'=>5 )),
				   array('Forestapproval' => array('user_id' => $this->User->id,'forest'=>6 )),
				   array('Forestapproval' => array('user_id' => $this->User->id,'forest'=>7 ))
				);                
              	$this->Forestapproval->saveAll($forest);
               

              	$wild = array(
				   array('Wildapproval' => array('user_id' => $this->User->id,'wild'=>1 )),
				   array('Wildapproval' => array('user_id' => $this->User->id,'wild'=>2 )),
				   array('Wildapproval' => array('user_id' => $this->User->id,'wild'=>3 )),
				   array('Wildapproval' => array('user_id' => $this->User->id,'wild'=>4 )),
				   array('Wildapproval' => array('user_id' => $this->User->id,'wild'=>5 )),
				   array('Wildapproval' => array('user_id' => $this->User->id,'wild'=>6 ))
				);
             	$this->Wildapproval->saveAll($wild);
            

				
				$this->Session->setFlash('Successfully registered!');
			    //$this->redirect(array('action'=>'index'));
               

			}else{
				$this->Session->setFlash('Could not be registered');
			}
		}
    }

    public function member_login(){
    	$this->redirect('/users/login');
    }

    public function member_logout(){
    	$this->Auth->logout();
    	$this->redirect('/users/login');
    }

    public function admin_login(){
    	$this->redirect('/users/login');
    }

      public function admin_logout(){
    	$this->Auth->logout();
    	$this->redirect('/users/login');
    }
}