<?php
App::uses('AppController', 'Controller');

class PostsController extends AppController {

    public $components = array('Paginator', 'Session');

    public $uses = array('Comment',
                         'Complaint',
                         'denrofficial',
                         'Post',
                         'User',
                         'Landagri',
                         'Landin',
                         'Landmi',
                         'Landre',
                         'Landcon',
                         'Forestchain',
                         'Forestwood',
                         'Forestlumb',
                         'Forestdealer',
                         'Forestcert',
                         'Forestsup',
                         'Forestplant',
                         'Wildlifefarm',
                         'Wildlifelocal'
    );

    public function index() {
        $this->Post->recursive = 0;
        $this->set('posts', $this->Paginator->paginate());
    }

    public function forum($id = null) {
        if($this->request->is('post')){
            if (!empty($this->request->data)) {
                $this->request->data['Post']['user_id'] = $this->Auth->user('id');
                if ($this->Post->saveAll($this->request->data)) {
                    $this->redirect('forum');
                    }
                }
            }

        $this->set('posts',$this->Post->find('all',array('order'=>array('Post.created ASC'))));

        $this->set('postcount',$this->Post->find('count'));
        
        $result = $this->Post->find('all',array('limit' => 5 ,'order'=>array('Post.comment_count DESC')));
        $this->set('comment',$result);

        $this->set('comments',$this->Post->find('all', array('limit' => 5 , 'order'=>array('Post.created DESC'))));

    }
    public function view($id = null) {
        if (!$this->Post->exists($id)) {
            throw new NotFoundException(__('Invalid post'));
        }
        
        $options = array('conditions' => array('Post.' . $this->Post->primaryKey => $id),);
        $this->set('post', $this->Post->find('first', $options));

        $result = $this->Post->find('all',array('order'=>array('Post.created ASC')));
        $this->set('comment',$result);

        $this->set('comments',$this->Post->find('all', array('limit' => 5 , 'order'=>array('Post.created DESC'))));

        /* Adding related comments */
        if ($this->request->is('post')) {
            $this->Comment->create();
            if(!empty($this->request->data)){
               $this->request->data['Comment']['post_id'] = $id;
               $this->request->data['Comment']['user_id'] = $this->Auth->user('id');

            if ($this->Comment->save($this->request->data)) {
                 $this->redirect($this->here);
            } else {
                $this->Session->setFlash(__('The comment could not be saved. Please, try again.'));
            }
        }
        $posts = $this->Comment->Post->find('list');
        $this->set(compact('posts'));
        }
    }
    
    public function complaint() {
        $this->Post->recursive = 0;
        $this->set('posts', $this->Paginator->paginate());
    }

    public function delete($id = null) {
        $this->Post->id = $id;
        if (!$this->Post->exists()) {
            throw new NotFoundException(__('Invalid post'));
        }
        $this->request->allowMethod('post', 'delete');
        if ($this->Post->delete()) {
            $this->Session->setFlash(__('The post has been deleted.'));
        } else {
            $this->Session->setFlash(__('The post could not be deleted. Please, try again.'));
        }
        return $this->redirect(array('action' => 'index'));
    }

    public function admin_delete($id = null) {
        $this->Post->id = $id;
        if (!$this->Post->exists()) {
            throw new NotFoundException(__('Invalid comment'));
        }
        $this->request->allowMethod('post', 'delete');
        if ($this->Post->delete()) {
            $this->Session->setFlash(__('The comment has been deleted.'));
        } else {
            $this->Session->setFlash(__('The comment could not be deleted. Please, try again.'));
        }
        return $this->redirect('forum');
    }



    
    public function member_index() {
        $this->Post->recursive = 0;
        $this->set('posts', $this->Paginator->paginate());
    }


    public function member_forum() {
        $this->set('posts',$this->Post->find('all'));
    }


    public function member_view($id = null) {
        $this->loadModel('User');
        if (!$this->Post->exists($id)) {
            throw new NotFoundException(__('Invalid post'));
        }
        $options = array('conditions' => array('Post.' . $this->Post->primaryKey => $id));
        $this->set('post', $this->Post->find('first', $options));
        $options2 = array('conditions' => array('User.' . $this->User->primaryKey => $id));
        $this->set('post2', $this->User->find('first', $options2));
    }


    public function member_edit($id = null) {
        if (!$this->Post->exists($id)) {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is(array('post', 'put'))) {
            if ($this->Post->save($this->request->data)) {
                $this->Session->setFlash(__('The post has been saved.'));
                return $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The post could not be saved. Please, try again.'));
            }
        } else {
            $options = array('conditions' => array('Post.' . $this->Post->primaryKey => $id));
            $this->request->data = $this->Post->find('first', $options);
        }
    }

    public function member_delete($id = null) {
        $this->Comment->id = $id;
        if (!$this->Comment->exists()) {
            throw new NotFoundException(__('Invalid post'));
        }
        $this->request->allowMethod('post', 'delete');
        if ($this->Comment->delete()) {
            $this->Session->setFlash(__('The post has been deleted.'));
        } else {
            $this->Session->setFlash(__('The post could not be deleted. Please, try again.'));
        }
        return $this->redirect($this->here);
    }


    public function member_application() {

    }

    public function admin_application() {

    }

    //LAND member application forms
    public function admin_landAgri() {

     }

     public function member_landAgri() {

     }
     
     public function admin_landInsular() {

     }
     public function member_landInsular() {

     }

     public function admin_landMis() {

     }
     public function member_landMis() {

     }
     
     public function admin_landRes() {

     }
     public function member_landRes() {

     }

     public function admin_landCons() {

     }
     public function member_landCons() {

     }

     //FOREST admin and member application forms
     public function admin_forestChains() {

     }
     public function member_forestChains() {

     }

     public function admin_forestWoods() {

     }
     public function member_forestWoods() {

     }

     public function admin_forestLumbs() {

     }
     public function member_forestLumbs() {

     }

     public function admin_forestDealers() {

     }
     public function member_forestDealers() {

     }

     public function admin_forestCerts() {

     }
     public function member_forestCerts() {

     }

     public function admin_forestSups() {

     }
     public function member_forestSups() {

     }

     public function admin_forestPlants() {

     }
     public function member_forestPlants() {

     }


     //WILDLIFE admin and member application forms
     public function admin_wildlifeFarms() {
        
     }
     public function member_wildlifeFarms() {
        
     }

     public function admin_wildlifeLocals() {

     }

     public function member_wildlifeLocals() {

     }



     //admin and member AJAX Calls for Land
     public function admin_landagriculture($pin = null){
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Landagri.name LIKE' => '%'.$pin.'%'),
                                                         array('Landagri.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Landagri->find('all', $condition);
            $this->set('result',$result);
        }
     }

     public function member_landagriculture($pin = null){
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Landagri.name LIKE' => '%'.$pin.'%'),
                                                         array('Landagri.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Landagri->find('all', $condition);
            $this->set('result',$result);
        }
     }

     public function admin_landinsularajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Landin.name LIKE' => '%'.$pin.'%'),
                                                         array('Landin.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Landin->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_landinsularajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Landin.name LIKE' => '%'.$pin.'%'),
                                                         array('Landin.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Landin->find('all', $condition);
            $this->set('result',$result);
        }

     }

     public function admin_landmiscellajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Landmi.name LIKE' => '%'.$pin.'%'),
                                                         array('Landmi.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Landmi->find('all', $condition);
            $this->set('result',$result);
        }

     }
      public function member_landmiscellajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Landmi.name LIKE' => '%'.$pin.'%'),
                                                         array('Landmi.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Landmi->find('all', $condition);
            $this->set('result',$result);
        }

     }

     public function admin_landresidentajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Landre.name LIKE' => '%'.$pin.'%'),
                                                         array('Landre.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Landre->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_landresidentajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Landre.name LIKE' => '%'.$pin.'%'),
                                                         array('Landre.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Landre->find('all', $condition);
            $this->set('result',$result);
        }

     }

     public function admin_landcondiajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Landcon.name LIKE' => '%'.$pin.'%'),
                                                         array('Landcon.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Landcon->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_landcondiajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Landcon.name LIKE' => '%'.$pin.'%'),
                                                         array('Landcon.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Landcon->find('all', $condition);
            $this->set('result',$result);
        }

     }


     //admin and member AJAX Calls for Forest
     public function admin_forestchainajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestchain.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestchain.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestchain->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_forestchainajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestchain.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestchain.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestchain->find('all', $condition);
            $this->set('result',$result);
        }

     }

     public function admin_forestwoodajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestwood.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestwood.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestwood->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_forestwoodajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestwood.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestwood.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestwood->find('all', $condition);
            $this->set('result',$result);
        }

     }

     public function admin_forestlumbajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestlumb.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestlumb.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestlumb->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_forestlumbajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestlumb.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestlumb.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestlumb->find('all', $condition);
            $this->set('result',$result);
        }

     }

     public function admin_forestdealerajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestdealer.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestdealer.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestdealer->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_forestdealerajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestdealer.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestdealer.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestdealer->find('all', $condition);
            $this->set('result',$result);
        }

     }

     public function admin_forestcertajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestcert.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestcert.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestcert->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_forestcertajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestcert.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestcert.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestcert->find('all', $condition);
            $this->set('result',$result);
        }

     }

     public function admin_forestsupajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestsup.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestsup.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestsup->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_forestsupajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestsup.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestsup.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestsup->find('all', $condition);
            $this->set('result',$result);
        }

     }

     public function admin_forestplantajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestplant.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestplant.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestplant->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_forestplantajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Forestplant.name LIKE' => '%'.$pin.'%'),
                                                         array('Forestplant.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Forestplant->find('all', $condition);
            $this->set('result',$result);
        }

     }


     //admin and member AJAX Calls for Wildlife
     public function admin_wildlifefarmajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Wildlifefarm.name LIKE' => '%'.$pin.'%'),
                                                         array('Wildlifefarm.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Wildlifefarm->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_wildlifefarmajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Wildlifefarm.name LIKE' => '%'.$pin.'%'),
                                                         array('Wildlifefarm.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Wildlifefarm->find('all', $condition);
            $this->set('result',$result);
        }

     }

     public function admin_wildlifelocalajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Wildlifelocal.name LIKE' => '%'.$pin.'%'),
                                                         array('Wildlifelocal.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Wildlifelocal->find('all', $condition);
            $this->set('result',$result);
        }

     }
     public function member_wildlifelocalajax($pin = NULL) {
        $this->layout = false;

        if(isset($pin) != NULL) {
            $condition = array('conditions'=>
                                            array('OR'=>array(
                                                         array('Wildlifelocal.name LIKE' => '%'.$pin.'%'),
                                                         array('Wildlifelocal.pin LIKE' => '%'.$pin.'%')
                                                        )
                                            )
                               );
            $result = $this->Wildlifelocal->find('all', $condition);
            $this->set('result',$result);
        }

     }




     //admin and member pdf printing for land
     public function admin_landagripdf($id = null){
            $this->layout='pdfTemp';
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Landagri->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_landagripdf($id = null){
            $this->layout='pdfTemp';
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Landagri->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

    public function admin_landinspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Landin->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
    public function member_landinspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Landin->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     public function admin_landmispdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Landmi->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_landmispdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Landmi->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     public function admin_landrespdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Landre->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_landrespdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Landre->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     public function admin_landconspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Landcon->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_landconspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Landcon->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     //admin and member pdf printing for forest
     public function admin_forestchainspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestchain->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_forestchainspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestchain->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     public function admin_forestwoodspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestwood->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_forestwoodspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestwood->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     public function admin_forestlumbspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestlumb->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_forestlumbspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestlumb->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     public function admin_forestdealerspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestdealer->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_forestdealerspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestdealer->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     public function admin_forestcertspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestcert->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_forestcertspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestcert->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     public function admin_forestsupspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestsup->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_forestsupspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestsup->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     public function admin_forestplantspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestplant->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_forestplantspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Forestplant->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }




     //admin and member pdf printing for Wildlife
     public function admin_wildlifefarmspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Wildlifefarm->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
     public function member_wildlifefarmspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Wildlifefarm->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

      public function admin_wildlifelocalspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Wildlifelocal->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }
      public function member_wildlifelocalspdf($id = null){
            $this->layout='pdfTemp';
            
            error_reporting(0);
            App::import('Vendor', 'MPDF', array('file' => 'MPDF'.DS.'mpdf.php'));

            if(isset($id) != null){
                $result = $this->Wildlifelocal->findById($id);
                $this->set('result',$result);
            } else {
                $result = null;
                $this->set('result',$result);
            }
     }

     //statistics
     public function member_stats(){
        
        $this->set('default',$this->Complaint->byYear(date('Y')));

     }

     public function member_year($year){
        $this->layout = false;
        $this->set('default',$this->Complaint->byYear($year));
     }


     public function member_month($year,$from,$till){
        $this->layout = false;
        $this->set('default',$this->Complaint->byMonth($year,$from,$till));
     }


     


    public function admin_forum() {
        $this->set('posts',$this->Post->find('all'));
    }

     public function admin_index() {
        $this->Post->recursive = 0;
        $this->set('posts', $this->Paginator->paginate());
    }

    public function admin_complaint() {
        $this->Post->recursive = 0;
        $this->set('posts', $this->Paginator->paginate());
    }


    public function admin_view($id = null) {
        if (!$this->Post->exists($id)) {
            throw new NotFoundException(__('Invalid post'));
        }
        $options = array('conditions' => array('Post.' . $this->Post->primaryKey => $id));
        $this->set('post', $this->Post->find('first', $options));
        $options2 = array('conditions' => array('User.' . $this->User->primaryKey => $id));
        $this->set('post2', $this->User->find('first', $options2));

        /* Adding related comments */
        if ($this->request->is('post')) {
            $this->Comment->create();
            if(!empty($this->request->data)){
               $this->request->data['Comment']['post_id'] = $id;
               $this->request->data['Comment']['user_id'] = $this->Auth->user('id');

            if ($this->Comment->save($this->request->data)) {
                 $this->redirect($this->here);
            } else {
                $this->Session->setFlash(__('The comment could not be saved. Please, try again.'));
            }
        }
        $posts = $this->Comment->Post->find('list');
        $this->set(compact('posts'));
        }
    }





    public function admin_add() {
        if ($this->request->is('post')) {
            $this->Post->create();
            if ($this->Post->save($this->request->data)) {
                $this->Session->setFlash(__('The post has been saved.'));
                return $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The post could not be saved. Please, try again.'));
            }
        }
    }

    public function admin_edit($id = null) {
        if (!$this->Post->exists($id)) {
            throw new NotFoundException(__('Invalid post'));
        }
        if ($this->request->is(array('post', 'put'))) {
            if ($this->Post->save($this->request->data)) {
                $this->Session->setFlash(__('The post has been saved.'));
                return $this->redirect(array('action' => 'index'));
            } else {
                $this->Session->setFlash(__('The post could not be saved. Please, try again.'));
            }
        } else {
            $options = array('conditions' => array('Post.' . $this->Post->primaryKey => $id));
            $this->request->data = $this->Post->find('first', $options);
        }
    }

    public function admin_stats(){
        $this->set('default',$this->Complaint->byYear(date('Y')));
    }

    //AJAX admin statistic 
    public function admin_year($year){
        $this->layout = false;
        $this->set('default',$this->Complaint->byYear($year));
    }


     public function admin_month($year,$from,$till){
        $this->layout = false;
        $this->set('default',$this->Complaint->byMonth($year,$from,$till));
    }
    
}
