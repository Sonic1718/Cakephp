<?php
App::uses('AppmModel','Model');

class Landapproval extends AppModel {

	public $belongsTo = 'User';

}

