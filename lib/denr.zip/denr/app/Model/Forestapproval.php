<?php
App::uses('AppmModel','Model');

class Forestapproval extends AppModel {

	public $belongsTo = 'User';

}

