<?php
App::uses('AppmModel','Model');

class Wildapproval extends AppModel {

	public $belongsTo = 'User';

}

