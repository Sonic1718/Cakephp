<?php

App::uses('AppModel','Model');

class Forestsup extends AppModel {

	#public $hasMany = 'Forestsupapplication';

	public $validate = array(


		'name' => array(
			 'name1' => array(
			 	'rule' => 'notEmpty',
			 'message' => ''
			),
			 'name2' => array(
			 	'rule' => '/^[\w.-]+$/',
			 'message' => 'Only letters allowed' 
			)
		),
		'address' => array(
			 'add1' => array(
			 	'rule' => 'notEmpty',
			 'message' => ''
			),
			 'add2' => array(
			 	'rule' => '/^[\w.-]+$/',
			 'message' => 'Only alpha numeric allowed' 
			)
		)




	);	
}