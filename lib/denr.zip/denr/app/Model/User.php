<?php

App::uses('AppModel', 'Model');


class User extends Model {
	

	public $validate = array(
			'fname' => array(
				'notEmpty' => array(
					'rule' => array('notEmpty'),
					'message' => 'Please enter your firstname',
				),
			),
			'fname' => array(
				'notEmpty' => array(
					'rule' => array('notEmpty'),
					'message' => 'Please enter your lastname',
				),
			),
			'username' => array(
				'notEmpty' => array(
					'rule' => array('between',5,15),
					'message' => 'The username must be between 5 and 15 characters.',
				),
			),
			'email' => array(
				'notEmpty'=>array(
					'rule'=>array('email'),
					'message'=>'Please enter valid email address'
					),
				),
			'password'=>array(
				'notEmpty'=> array(
					'rule'=> array('between', 8, 40),
					'message'=>'Your password must be between 8 and 40 characters.'
				),
				'matchPasswords' => array(
					'rule'=> array('matchPasswords'),
					'message'=>'Your password do not match'
					),
				),
			);


	public function matchPasswords($data){
		if($data['password'] == $this->data['User']['confirm_password']){
			return true;
		}
		$this->invalidate('confirm_password', 'Your passwords do not match');
    return false;
	}



	public function beforeSave($options = array()){
	 	if(isset($this->data[$this->alias]['password'])){ 	
		 	$this->data[$this->alias]['password'] = AuthComponent::password($this->data[$this->alias]['password']);
	 	}
	return true;
	}

	public $hasMany = array(
		'Post' => array(
			'className' => 'Post',
			'foreignKey' => 'user_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		),
		'Comment' => array(
			'className' => 'Comment',
			'foreignKey' => 'user_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
?>