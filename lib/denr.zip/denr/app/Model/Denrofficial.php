<?php

App::uses('AppModel', 'Model');


class Denrofficial extends Model {
	public $name = "User";

}
?>